﻿namespace OrganDonorsManagementSystem.UI
{
    partial class frmOrganMatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOrganMatch));
            this.dgvRequests = new System.Windows.Forms.DataGridView();
            this.btnMatchDonor = new System.Windows.Forms.Button();
            this.cmbFilter = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkShowIncompatibleDonors = new System.Windows.Forms.CheckBox();
            this.btnSelectDonor = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvRequests
            // 
            this.dgvRequests.BackgroundColor = System.Drawing.Color.White;
            this.dgvRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRequests.Location = new System.Drawing.Point(158, 81);
            this.dgvRequests.Name = "dgvRequests";
            this.dgvRequests.RowHeadersWidth = 51;
            this.dgvRequests.RowTemplate.Height = 24;
            this.dgvRequests.Size = new System.Drawing.Size(1039, 534);
            this.dgvRequests.TabIndex = 0;
            this.dgvRequests.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRequests_CellContentClick);
            // 
            // btnMatchDonor
            // 
            this.btnMatchDonor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(76)))), ((int)(((byte)(58)))));
            this.btnMatchDonor.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMatchDonor.ForeColor = System.Drawing.Color.White;
            this.btnMatchDonor.Location = new System.Drawing.Point(565, 643);
            this.btnMatchDonor.Name = "btnMatchDonor";
            this.btnMatchDonor.Size = new System.Drawing.Size(205, 62);
            this.btnMatchDonor.TabIndex = 1;
            this.btnMatchDonor.Text = "Match Donor";
            this.btnMatchDonor.UseVisualStyleBackColor = false;
            this.btnMatchDonor.Click += new System.EventHandler(this.btnMatchDonor_Click);
            // 
            // cmbFilter
            // 
            this.cmbFilter.BackColor = System.Drawing.Color.White;
            this.cmbFilter.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFilter.FormattingEnabled = true;
            this.cmbFilter.Items.AddRange(new object[] {
            "Pending Requests",
            "Completed Requests",
            "All Requests"});
            this.cmbFilter.Location = new System.Drawing.Point(1225, 81);
            this.cmbFilter.Name = "cmbFilter";
            this.cmbFilter.Size = new System.Drawing.Size(129, 31);
            this.cmbFilter.TabIndex = 2;
            this.cmbFilter.SelectedIndexChanged += new System.EventHandler(this.cmbFilter_SelectedIndexChanged_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel1.Controls.Add(this.dgvRequests);
            this.panel1.Controls.Add(this.chkShowIncompatibleDonors);
            this.panel1.Controls.Add(this.btnSelectDonor);
            this.panel1.Controls.Add(this.btnMatchDonor);
            this.panel1.Controls.Add(this.cmbFilter);
            this.panel1.Location = new System.Drawing.Point(-7, -31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1855, 870);
            this.panel1.TabIndex = 3;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // chkShowIncompatibleDonors
            // 
            this.chkShowIncompatibleDonors.AutoSize = true;
            this.chkShowIncompatibleDonors.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowIncompatibleDonors.Location = new System.Drawing.Point(1225, 81);
            this.chkShowIncompatibleDonors.Name = "chkShowIncompatibleDonors";
            this.chkShowIncompatibleDonors.Size = new System.Drawing.Size(236, 27);
            this.chkShowIncompatibleDonors.TabIndex = 4;
            this.chkShowIncompatibleDonors.Text = "Show incompatible donors";
            this.chkShowIncompatibleDonors.UseVisualStyleBackColor = true;
            this.chkShowIncompatibleDonors.CheckedChanged += new System.EventHandler(this.chkShowIncompatibleDonors_CheckedChanged);
            // 
            // btnSelectDonor
            // 
            this.btnSelectDonor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(76)))), ((int)(((byte)(58)))));
            this.btnSelectDonor.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectDonor.ForeColor = System.Drawing.Color.White;
            this.btnSelectDonor.Location = new System.Drawing.Point(565, 643);
            this.btnSelectDonor.Name = "btnSelectDonor";
            this.btnSelectDonor.Size = new System.Drawing.Size(208, 62);
            this.btnSelectDonor.TabIndex = 3;
            this.btnSelectDonor.Text = "Select Donor";
            this.btnSelectDonor.UseVisualStyleBackColor = false;
            this.btnSelectDonor.Visible = false;
            this.btnSelectDonor.Click += new System.EventHandler(this.btnSelectDonor_Click_1);
            // 
            // frmOrganMatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1485, 767);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmOrganMatch";
            this.Text = "Match Organs";
            this.Load += new System.EventHandler(this.frmOrganMatch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvRequests;
        private System.Windows.Forms.Button btnMatchDonor;
        private System.Windows.Forms.ComboBox cmbFilter;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSelectDonor;
        private System.Windows.Forms.CheckBox chkShowIncompatibleDonors;
    }
}