﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrganDonorsManagementSystem.BLL;
using OrganDonorsManagementSystem.DAL;


namespace OrganDonorsManagementSystem.UI
{
    public partial class frmRequests : Form
    {
        public frmRequests()
        {
            InitializeComponent();
        }
        public void Clear()
        {
            // Clear all the request-related text boxes and combo boxes
            txtPatientName.Text = "";
            cmbOrganType.SelectedIndex = -1;
            cmbBloodType.SelectedIndex = -1;
            txtContact.Text = "";
            txtMedicalHistory.Text = "";
            txtHLAMarker.Text = "";
            txtRequesterEmail.Text = "";
            cmbUrgency.SelectedIndex = -1;
            cmbGender.SelectedIndex = -1;
            txtAddress.Text = "";

            // Clear the PictureBox
            string path = Application.StartupPath.Substring(0, Application.StartupPath.Length - 10);
            string imagePath = path + "\\images\\no-image.jpg";
           // picProfile.Image = new Bitmap(imagePath);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            // Create and populate the request object using your form's controls.
            requestBLL r = new requestBLL
            {
                patient_name = txtPatientName.Text,
                organ_type = cmbOrganType.Text,
                blood_type = cmbBloodType.Text,
                contact = txtContact.Text,
                Medical_History = txtMedicalHistory.Text,
                hla_markers = txtHLAMarker.Text,
                status = "Pending",
                requester_email = txtRequesterEmail.Text,
                urgency = cmbUrgency.Text,
                gender = cmbGender.Text,
                address = txtAddress.Text,
                requested_date = DateTime.Now // Set current date/time for the request.
            };

            // Create instances of the DAL classes.
            requestDAL dal = new requestDAL();
            userDAL udal = new userDAL();

            // Get the logged-in user's ID (assuming frmLogin.loggedInUser holds the username)
            userBLL usr = udal.GetIDFromUsername(frmLogin.loggedInUser);
            r.added_by = usr.user_id;  // Assign the logged-in user's ID to added_by

            // Convert the profile picture from PictureBox to a byte array (if an image is selected)
            if (pictureBoxProfilePicture.Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    pictureBoxProfilePicture.Image.Save(ms, pictureBoxProfilePicture.Image.RawFormat);
                    r.profile_picture = ms.ToArray();
                }
            }
            else
            {
                r.profile_picture = null;
            }

            // Insert the new request into the database.
            bool isSuccess = dal.Insert(r);
            if (isSuccess)
            {
                MessageBox.Show("Request Submitted Successfully!");
                Clear();  // Call your method to clear the form controls.
            }
            else
            {
                MessageBox.Show("Failed to Submit Request.");
            }
        }
        private void frmRequests_Load(object sender, EventArgs e)
        {
            cmbUrgency.Items.AddRange(new string[] { "Low", "Medium", "High" });
            cmbUrgency.SelectedIndex = 0; // Default to Low

        }

        private void btnSelectImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif";
            if (open.ShowDialog() == DialogResult.OK)
            {
                pictureBoxProfilePicture.Image = new Bitmap(open.FileName);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}
