﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using OrganDonorsManagementSystem.DAL;
using OrganDonorsManagementSystem.Helpers;  // Ensure this matches your project structure

namespace OrganDonorsManagementSystem.UI
{
    public partial class frmDonorDetails : Form
    {
        private DataRow donorData;
        private string receiverPhone;
        private string receiverName;
        private string requesterEmail;
        private string urgency;
        private string recipientHLAMarkers;


        // Three-parameter constructor (DataRow, receiverPhone, receiverName)
        public frmDonorDetails(DataRow donorRow, string receiverPhoneNumber, string receiverName, string requesterEmail, string urgency, string recipientHLAMarkers)
        {
            InitializeComponent();
            donorData = donorRow;
            receiverPhone = receiverPhoneNumber;
            this.receiverName = receiverName;
            this.requesterEmail = requesterEmail;
            this.urgency = urgency;
            this.recipientHLAMarkers = recipientHLAMarkers;
            PopulateDonorDetails();
        }

        private void PopulateDonorDetails()
        {
            lblName.Text = donorData["first_name"].ToString() + " " + donorData["last_name"].ToString();
            lblMedicalHistory.Text = donorData["address"].ToString();
            lblContact.Text = donorData["contact"].ToString();
            lblMedicalHistory.Text = donorData["Medical_History"].ToString();
            lblOrganType.Text = donorData["organ_type"].ToString();
            lblDonorBloodGroup.Text = donorData["blood_group"].ToString();
            lblHLA.Text = donorData["hla_markers"].ToString();
            lblCrossmatchResults.Text = donorData["crossmatch_result"].ToString();

            // Check if profile_picture exists and is not null
            if (donorData["profile_picture"] != DBNull.Value)
            {
                byte[] imageBytes = (byte[])donorData["profile_picture"];
                using (MemoryStream ms = new MemoryStream(imageBytes))
                {
                    pictureBoxProfilePicture.Image = Image.FromStream(ms);
                }
            }
            else
            {
                // Set a default "no image" picture if no profile picture is available
                string path = Application.StartupPath.Substring(0, (Application.StartupPath.Length) - 10);
                string defaultImagePath = Path.Combine(path, "images", "no-image.jpg");
                pictureBoxProfilePicture.Image = Image.FromFile(defaultImagePath);
            }
        }
        /// <summary>
        /// When the Notify button is clicked, sends SMS and email notifications,
        /// updates the request status to 'Done', and sets the donor status to 'Unavailable'.
        /// </summary>
        private async void btnNotify_Click(object sender, EventArgs e)
        {
            
            // SMS notification

            string smsMessage = $"Dear {receiverName}, a compatible organ donor has been found. Please check your email for next steps.";
            Fast2SmsQuickSender smsHelper = new Fast2SmsQuickSender();
            try
            {
                await smsHelper.SendQuickSmsAsync(receiverPhone, smsMessage);
                MessageBox.Show("SMS notification sent successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to send SMS: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            

            // Email notification
            string emailSubject = "Organ Transplant Match Found – Next Steps";
            string emailBody = $@"
Dear {receiverName},

We are pleased to inform you that a suitable organ donor has been identified for your pending transplant request. This is an important and time-sensitive development, and we kindly urge you to take immediate action to move forward with the process.

Here’s what you need to do next:
1. **Contact the Transplant Coordination Office:** Please reach out to our office at (123) 456-7890 as soon as possible to confirm your availability and readiness. Delays may affect the success of the transplant.
2. **Schedule an Urgent Consultation:** We will arrange a comprehensive consultation to discuss medical preparations, required evaluations, and the anticipated timeline for the transplant.
3. **Complete Pre-Transplant Evaluations:** Ensure that all necessary tests and documentation are up-to-date to avoid any delays.
4. **Prepare for Hospital Admission:** Once all steps are finalized, our team will coordinate your admission and surgical arrangements for the procedure.

We understand that this is an emotional and critical time, and we want you to know that our dedicated medical team will be with you at every step of this journey. Should you have any questions or concerns, please don’t hesitate to contact our support line.

Thank you for your patience and trust in our services. Together, we will work toward a successful and life-changing transplant.

Sincerely,  
The Transplant Coordination Team  
(Your Hospital/Organization Name)  
Contact: (123) 456-7890  
Email: support@transplantcenter.org  
Office Hours: Monday to Friday, 8 AM - 6 PM";
;

            // Send email
            EmailHelper emailHelper = new EmailHelper();
            try
            {
                await emailHelper.SendEmailAsync(requesterEmail, emailSubject, emailBody);
                MessageBox.Show("Email notification sent successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to send email: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            bool updateSuccess = UpdateRequestStatusToDone();
            if (updateSuccess)
            {
                MessageBox.Show("Request status updated to 'Done'.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to update request status.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            //Update donor status 

            donorDAL dDAL = new donorDAL();
            int donorId = Convert.ToInt32(donorData["donor_id"]); // Make sure 'donor_id' exists in donorData
            bool donorUpdateSuccess = dDAL.UpdateDonorStatus(donorId, "Unavailable");

            if (donorUpdateSuccess)
            {
                MessageBox.Show("Donor status updated to 'Unavailable'.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to update donor status.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }


        private bool UpdateRequestStatusToDone()
        {
            bool isSuccess = false;
            string connectionString = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string updateSql = "UPDATE tbl_requests SET status = 'Done' WHERE contact = @contact AND status = 'Pending'";
                    SqlCommand cmdUpdate = new SqlCommand(updateSql, conn);
                    cmdUpdate.Parameters.AddWithValue("@contact", receiverPhone);
                    int rows = cmdUpdate.ExecuteNonQuery();
                    isSuccess = rows > 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            return isSuccess;

           

        }


        private void frmDonorDetails_Load_1(object sender, EventArgs e)
        {
            // Intentionally left blank.
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            // Intentionally left blank.
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblDonorBloodGroup_Click(object sender, EventArgs e)
        {

        }
    }
}
