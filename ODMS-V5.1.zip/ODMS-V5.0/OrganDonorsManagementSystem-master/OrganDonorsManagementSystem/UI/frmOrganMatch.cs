﻿using System;
using System.Data;
using System.Windows.Forms;
using OrganDonorsManagementSystem.DAL;
using OrganDonorsManagementSystem.BLL;
using System.Linq;

namespace OrganDonorsManagementSystem.UI
{
    public partial class frmOrganMatch : Form
    {
        private DataRow originalRequestData;
        private string requesterEmail;

        // This variable stores the original request row (with the requester's details)
        


        public frmOrganMatch()
        {
            InitializeComponent();
        }

        // Loads requests based on the selected filter
        private void LoadRequests(string filter)
        {
            requestDAL dal = new requestDAL();
            DataTable dt;

            if (filter == "Pending Requests")
                dt = dal.GetRequestsByStatus("Pending");
            else if (filter == "Completed Requests")
                dt = dal.GetRequestsByStatus("Done");
            else
                dt = dal.GetAllRequests();

            dgvRequests.DataSource = dt;
        }

        private void frmOrganMatch_Load(object sender, EventArgs e)
        {
            cmbFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbFilter.Items.Clear();
            cmbFilter.Items.Add("Pending Requests");
            cmbFilter.Items.Add("Completed Requests");
            cmbFilter.Items.Add("All Requests");
            cmbFilter.SelectedIndex = 0;

            LoadRequests(cmbFilter.SelectedItem.ToString());

            // Hide "Select Donor" button and "Show Incompatible Donors" checkbox initially
            btnSelectDonor.Visible = false;
            chkShowIncompatibleDonors.Visible = false;
        }

        private void cmbFilter_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (cmbFilter.SelectedItem != null)
                LoadRequests(cmbFilter.SelectedItem.ToString());
        }

        // Match Donor button: runs the matching algorithm and updates the grid with donor rows
        private void btnMatchDonor_Click(object sender, EventArgs e)
        {
            if (dgvRequests.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a request row first.");
                return;
            }

            // Get the DataRowView from the selected row and store its underlying DataRow
            DataRowView drv = dgvRequests.SelectedRows[0].DataBoundItem as DataRowView;
            if (drv == null)
            {
                MessageBox.Show("Unable to retrieve request data.");
                return;
            }
            originalRequestData = drv.Row;

            // Extract request details from the DataRow
            requesterEmail = originalRequestData["requester_email"]?.ToString();
            string organType = originalRequestData["organ_type"].ToString();
            string bloodType = originalRequestData["blood_type"].ToString();
            string hlaMarkers = originalRequestData["hla_markers"]?.ToString() ?? "";

            // Create a request object using these details.
            requestBLL req = new requestBLL
            {
                organ_type = organType,
                blood_type = bloodType,
                hla_markers = hlaMarkers
            };

            // Call the advanced matching algorithm
            requestDAL dal = new requestDAL();
            DataTable matches = dal.AdvancedMatchDonor(req);
            foreach (DataColumn col in matches.Columns)
            {
                string columns = string.Join(", ", matches.Columns.Cast<DataColumn>().Select(c => c.ColumnName));
                
            }
            if (!matches.Columns.Contains("CompatibilityScore"))
            {
                matches.Columns.Add("CompatibilityScore", typeof(int));
               
            }

            foreach (DataRow row in matches.Rows)
            {
                if (row["crossmatch_result"]?.ToString().ToUpper() == "POSITIVE")
                {
                    string donorName = $"{row["first_name"]} {row["last_name"]}";
                    MessageBox.Show($"{row["first_name"]} {row["last_name"]}");

                    string donorHLA = row["hla_markers"]?.ToString() ?? "";
                    string recipientHLA = req.hla_markers ?? "";

                    int hlaScore = dal.CalculateHLAMatchScore(donorHLA, recipientHLA);
                    int score = hlaScore * 5;

                    row["CompatibilityScore"] = score;
                   
                     donorName = $"{row["first_name"]} {row["last_name"]}";
                    MessageBox.Show($"Donor: {donorName}, Score: {row["CompatibilityScore"]}");
                }
            }

            // Debug: Confirm scores
            Console.WriteLine(matches.Rows.Count);
            foreach (DataRow row in matches.Rows)
            {
                string donorName = $"{row["first_name"]} {row["last_name"]}";
                Console.WriteLine($"Donor: {donorName}, Score: {row["CompatibilityScore"]}");
            }

            // Update the DataGridView
            dgvRequests.DataSource = matches;

            foreach (DataRow row in matches.Rows)
            {
                string donorName = $"{row["first_name"]} {row["last_name"]}";
                Console.WriteLine($"Donor: {donorName}, Score: {row["CompatibilityScore"]}");
            }


            // Update the grid with matching donor records.
            dgvRequests.DataSource = matches;
            // Ensure CompatibilityScore column exists in the DataGridView
            if (!dgvRequests.Columns.Contains("CompatibilityScore"))
            {
                dgvRequests.Columns.Add("CompatibilityScore", "Compatibility Score");
            }
            dgvRequests.Columns["CompatibilityScore"].Visible = true;

            btnSelectDonor.Visible = (matches.Rows.Count > 0);
            chkShowIncompatibleDonors.Visible = (matches.Rows.Count > 0);

            //Hide the req filter 
            cmbFilter.Visible = false;

            if (matches.Rows.Count > 0)
                MessageBox.Show("Matching donors are now displayed. Please select a donor from the list.");
            else
                MessageBox.Show("No matching donor found.");




            if (matches.Rows.Count > 0)
                MessageBox.Show("Matching donors are now displayed. Please select a donor from the list.");
            else
                MessageBox.Show("No matching donor found.");
        }

        // Select Donor button: opens frmDonorDetails for the selected donor
        private void btnSelectDonor_Click_1(object sender, EventArgs e)
        {
            if (dgvRequests.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a donor from the list.");
                return;
            }

            // Get the selected donor row from the updated grid.
            DataGridViewRow selectedDonorRow = dgvRequests.SelectedRows[0];
            DataTable dt = (DataTable)dgvRequests.DataSource;
            DataRow donorData = dt.Rows[selectedDonorRow.Index];

            if (originalRequestData == null)
            {
                MessageBox.Show("Original request data is missing.");
                return;
            }

            // Retrieve requester's details from the stored DataRow
            string receiverPhone = originalRequestData["contact"].ToString();
            string receiverName = originalRequestData["patient_name"].ToString();
            string urgency = originalRequestData["urgency"].ToString();
            string recipientHlaMarkers = originalRequestData["hla_markers"].ToString();

            // Open frmDonorDetails using the three-parameter constructor.
            frmDonorDetails donorDetailsForm = new frmDonorDetails(donorData, receiverPhone, receiverName, requesterEmail, urgency, recipientHlaMarkers);
            donorDetailsForm.ShowDialog();
        }

        // (Optional) Empty handler if designer still expects it
        private void dgvRequests_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Not used.
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void chkShowIncompatibleDonors_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowIncompatibleDonors.Checked)
            {
                // Show incompatible donors
                requestDAL dal = new requestDAL();
                DataTable incompatibleDonors = dal.GetIncompatibleDonors(); // You’ll need to implement this method
                dgvRequests.DataSource = incompatibleDonors;
            }
            else
            {
                // Show matching donors again
                if (originalRequestData != null)
                {
                    requestBLL req = new requestBLL
                    {
                        organ_type = originalRequestData["organ_type"].ToString(),
                        blood_type = originalRequestData["blood_type"].ToString(),
                        hla_markers = originalRequestData["hla_markers"]?.ToString() ?? ""
                    };

                    requestDAL dal = new requestDAL();
                    DataTable matches = dal.AdvancedMatchDonor(req);
                    dgvRequests.DataSource = matches;
                }
            }
        }
    }
}
