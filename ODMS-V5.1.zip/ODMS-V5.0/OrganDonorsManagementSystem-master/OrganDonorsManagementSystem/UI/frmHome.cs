﻿using OrganDonorsManagementSystem.DAL;
using OrganDonorsManagementSystem.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrganDonorsManagementSystem
{
    public partial class frmHome : Form
    {
        public frmHome()
        {
            InitializeComponent();
        }

        //Create the Object of Donor Dal
        donorDAL dal = new donorDAL();

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            //Code to Close this Application
            this.Hide();
        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Open Users Form
            frmUsers users = new frmUsers();
            users.Show();
        }

        private void donorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Open Manage Donors Form
            frmDonors donors = new frmDonors();
            donors.Show();
        }

        private void frmHome_Load(object sender, EventArgs e)
        {

            // Check if the logged-in user is admin
            if (frmLogin.loggedInUser.ToLower() == "admin")
            {
                usersToolStripMenuItem.Visible = true; // Show the Users menu item
            }
            else
            {
                usersToolStripMenuItem.Visible = false; // Hide it for non-admin users
            }
            //Load all the Blood Donors Count When Form is Loaded
            //Call allDonorCountMethod
            allDonorCount();

            // Display all the Donors, but REMOVE the profile picture column
            DataTable dt = dal.Select();

            if (dt.Columns.Contains("profile_picture"))
            {
                dt.Columns.Remove("profile_picture"); // Remove it before binding
            }

            dgvDonors.DataSource = dt;


            //Display the username of Logged In user
            lblUser.Text = frmLogin.loggedInUser;
        }

        public void allDonorCount()
        {
            //Get the Donor Count from DAtabase and SEt in respective label
            lblOpositiveCount.Text = dal.countDonors("Heart");
            lblOnegativeCount.Text = dal.countDonors("Kidney");
            lblApositiveCount.Text = dal.countDonors("Liver");
            lblAnegativeCount.Text = dal.countDonors("Lungs");
            lblBpositiveCount.Text = dal.countDonors("Cornea");
            lblBnegativeCount.Text = dal.countDonors("Uterus");
            lblABpositiveCount.Text = dal.countDonors("Bone Marrow");
            lblABnegativeCount.Text = dal.countDonors("Skin");
        }

        private void frmHome_Activated(object sender, EventArgs e)
        {
            //Call allDonorCount Method
            allDonorCount();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            //Get the Keywords from the SEarch TextBox
            string keywords = txtSearch.Text;

            //Check whether the TextBox is Empty or Not
            if(keywords != null)
            {
                //Filter the Donors based on Keywords
                DataTable dt = dal.Search(keywords);
                dgvDonors.DataSource = dt;
            }
            else
            {
                //DIsplay all the Donors
                DataTable dt = dal.Select();
                dgvDonors.DataSource = dt;
            }
        }

        private void lblAppName_Click(object sender, EventArgs e)
        {

        }

        private void lblOpositiveCount_Click(object sender, EventArgs e)
        {

        }

        private void dgvDonors_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnOpenRequestForm_Click(object sender, EventArgs e)
        {
            // Create an instance of the Organ Request form
    frmRequests requestForm = new frmRequests();

            // Show the form
            requestForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create an instance of the Organ Request form
            frmOrganMatch matchForm = new frmOrganMatch();

            // Show the form
            matchForm.Show();
        }
    }
}
