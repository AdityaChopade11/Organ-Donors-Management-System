﻿using OrganDonorsManagementSystem.BLL;
using OrganDonorsManagementSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrganDonorsManagementSystem.UI
{
    public partial class frmDonors : Form
    {
        private int GetPreservationDays(string organType)
        {
            switch (organType.ToLower())
            {
                case "heart": return 1;      // For demonstration, assume 1 day
                case "lungs": return 1;      // 1 day
                case "liver": return 2;      // 2 days
                case "kidney": return 3;     // 3 days
                case "pancreas": return 2;   // 2 days
                default: return 2;           // Default to 2 days for others
            }
        }
        public frmDonors()
        {
            InitializeComponent();
        }
        //Create object of Donor BLL and Donor DAL
        donorBLL d = new donorBLL();
        donorDAL dal = new donorDAL();
        userDAL udal = new userDAL();

        //Global Variable for Image
        string imageName = "no-image.jpg";
        string sourcePath = "";
        string destinationPath = "";

        string rowHeaderImage;

        private void frmDonors_Load(object sender, EventArgs e)
        {
            //Display Donors in DataGrid View
            DataTable dt = dal.Select();
            // Hide the profile_picture column if it's being added
            if (dt.Columns.Contains("profile_picture"))
            {
                dt.Columns.Remove("profile_picture");
            }
            // Now set the cleaned data to the DGV
            dgvDonors.DataSource = dt;

            //First we need to get the image Path
            string path = Application.StartupPath.Substring(0, (Application.StartupPath.Length) - 10);

            string imagepath = path + "\\images\\no-image.jpg";

            //Display Image in PictureBox
            pictureBoxProfilePicture.Image = new Bitmap(imagepath);
        }

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            //Close this form
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Step 1. Get the data from the Manage Donors Form
            d.first_name = txtFirstName.Text;
            d.last_name = txtLastName.Text;
            d.email = txtEmail.Text;
            d.gender = cmbGender.Text;
            d.organ_type = cmbOrganType.Text;
            d.contact = txtContact.Text;
            d.address = txtAddress.Text;
            d.added_date = DateTime.Now;
            d.blood_group = cmbBloodGroup.Text;
            d.Medical_History = txtMedicalHis.Text;
            d.hla_markers = txtHLAMarker.Text.Trim();
            d.donor_status = "Available";
            d.organ_status = "Valid";
            d.expiration_date = DateTime.Now.AddDays(GetPreservationDays(d.organ_type));
            // Default crossmatch_result to "NEGATIVE" if not selected
            if (cmbCrossmatch.SelectedItem != null)
            {
                d.crossmatch_result = cmbCrossmatch.SelectedItem.ToString();
            }
            else
            {
                d.crossmatch_result = "NEGATIVE";
            }

            // Get the ID of the logged-in user
            string loggedInUser = frmLogin.loggedInUser;
            userBLL usr = udal.GetIDFromUsername(loggedInUser);
            d.added_by = usr.user_id;

            // New: Instead of copying the image file, read the image from the PictureBox into a byte array.
            if (pictureBoxProfilePicture.Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    pictureBoxProfilePicture.Image.Save(ms, pictureBoxProfilePicture.Image.RawFormat);
                    d.profile_picture = ms.ToArray();
                }
            }
            else
            {
                d.profile_picture = null;
            }

            // Step2: Insert data into the database
            bool isSuccess = dal.Insert(d);

            if (isSuccess)
            {
                MessageBox.Show("New Donor Added Successfully");
                // Refresh DataGridView
                DataTable dt = dal.Select();
                dgvDonors.DataSource = dt;
                // Clear all text boxes
                Clear();
            }
            else
            {
                MessageBox.Show("Failed to Add new Donor.");
            }
        }

        //Create a Method to Clear all the Textboxes
        public void Clear()
        {
            //Clear all the TExtboxes
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtEmail.Text = "";
            txtDonorID.Text = "";
            cmbGender.Text = "";
            cmbOrganType.Text = "";
            txtContact.Text = "";
            txtAddress.Text = "";
            cmbBloodGroup.Text="";
            imageName = "no-image.jpg";
            txtMedicalHis.Text = "";
            txtHLAMarker.Text = "";
            cmbCrossmatch.Text = "";

            //Clear the PictureBox
            //First we need to get the image Path
            string path = Application.StartupPath.Substring(0, (Application.StartupPath.Length) - 10);

            string imagepath = path + "\\images\\no-image.jpg";

            //Display Image in PictureBox
            pictureBoxProfilePicture.Image = new Bitmap(imagepath);
        }

        private void dgvDonors_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;

            // Correctly map DataGridView columns to textboxes
            txtDonorID.Text = dgvDonors.Rows[rowIndex].Cells["donor_id"].Value.ToString();
            txtFirstName.Text = dgvDonors.Rows[rowIndex].Cells["first_name"].Value.ToString();
            txtLastName.Text = dgvDonors.Rows[rowIndex].Cells["last_name"].Value.ToString();
            txtEmail.Text = dgvDonors.Rows[rowIndex].Cells["email"].Value.ToString();
            cmbGender.Text = dgvDonors.Rows[rowIndex].Cells["gender"].Value.ToString();
            cmbOrganType.Text = dgvDonors.Rows[rowIndex].Cells["organ_type"].Value.ToString();
            cmbBloodGroup.Text = dgvDonors.Rows[rowIndex].Cells["blood_group"].Value.ToString();
            txtMedicalHis.Text = dgvDonors.Rows[rowIndex].Cells["medical_history"].Value.ToString();
            txtHLAMarker.Text = dgvDonors.Rows[rowIndex].Cells["hla_markers"].Value.ToString();
            cmbCrossmatch.Text = dgvDonors.Rows[rowIndex].Cells["crossmatch_result"].Value.ToString();
            txtContact.Text = dgvDonors.Rows[rowIndex].Cells["contact"].Value.ToString();
            txtAddress.Text = dgvDonors.Rows[rowIndex].Cells["address"].Value.ToString();

            // Fetch the donor's full data from the database — including the profile picture
            int donorId = Convert.ToInt32(dgvDonors.Rows[rowIndex].Cells["donor_id"].Value);
            DataTable fullDonorData = dal.GetDonorById(donorId);

            if (fullDonorData.Rows.Count > 0)
            {
                DataRow donorRow = fullDonorData.Rows[0];

                if (donorRow["profile_picture"] != DBNull.Value)
                {
                    byte[] imageBytes = (byte[])donorRow["profile_picture"];
                    using (MemoryStream ms = new MemoryStream(imageBytes))
                    {
                        pictureBoxProfilePicture.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    // Load a default "no image" picture
                    string path = Application.StartupPath.Substring(0, (Application.StartupPath.Length) - 10);
                    string defaultImagePath = Path.Combine(path, "images", "no-image.jpg");
                    pictureBoxProfilePicture.Image = Image.FromFile(defaultImagePath);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // 1. Gather the text field values into the donor BLL object
            d.donor_id = int.Parse(txtDonorID.Text);
            d.first_name = txtFirstName.Text;
            d.last_name = txtLastName.Text;
            d.email = txtEmail.Text;
            d.gender = cmbGender.Text;
            d.organ_type = cmbOrganType.Text;
            d.blood_group = cmbBloodGroup.Text;
            d.contact = txtContact.Text;
            d.address = txtAddress.Text;
            d.Medical_History = txtMedicalHis.Text;
            d.crossmatch_result = cmbCrossmatch.Text;
            d.hla_markers = txtHLAMarker.Text;

            // 2. If the user has selected a new image in btnSelectImage_Click, 
            //    we've already set d.profile_picture there. But if you want to ensure 
            //    we always store what's currently in the PictureBox, do:
            if (pictureBoxProfilePicture.Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    pictureBoxProfilePicture.Image.Save(ms, pictureBoxProfilePicture.Image.RawFormat);
                    d.profile_picture = ms.ToArray(); // store the image as byte array
                }
            }
            else
            {
                d.profile_picture = null; // or keep the old picture if you want
            }

            // 3. Update the donor in the database
            bool isSuccess = dal.Update(d);

            // 4. Check the result
            if (isSuccess)
            {
                MessageBox.Show("Donor updated successfully!");
                // Refresh the grid
                DataTable dt = dal.Select();
                dgvDonors.DataSource = dt;
                Clear();
            }
            else
            {
                MessageBox.Show("Failed to update donor.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Get the donor ID from the form
            d.donor_id = int.Parse(txtDonorID.Text);

            // Delete the donor record from the database
            bool isSuccess = dal.Delete(d);

            if (isSuccess)
            {
                MessageBox.Show("Donor Deleted Successfully.");
                Clear();

                // Refresh the DataGridView
                DataTable dt = dal.Select();
                dgvDonors.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Failed to Delete Donor");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //Clear the TExtboxes
            Clear();
        }

        private void btnSelectImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif";

            if (open.ShowDialog() == DialogResult.OK)
            {
                // Display in PictureBox
                pictureBoxProfilePicture.Image = new Bitmap(open.FileName);

                // Convert to byte array
                using (MemoryStream ms = new MemoryStream())
                {
                    pictureBoxProfilePicture.Image.Save(ms, pictureBoxProfilePicture.Image.RawFormat);
                    d.profile_picture = ms.ToArray(); // store the byte array in the BLL object
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            //Let's Add the Dunctionality to Search the Donors

            //1. Get the Keywords Typed on the Search TExt Box
            string keywords = txtSearch.Text;

            // Check Whether the Search TExtBox is Empty or Not
            if(keywords != null)
            {
                //Display the information of Donors Based on Keywords
                DataTable dt = dal.Search(keywords);
                dgvDonors.DataSource = dt;
            }
            else
            {
                //DIsplay all the Donors
                DataTable dt = dal.Select();
                dgvDonors.DataSource = dt;
            }
        }

        private void cmbOrganType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblCrossMatch_Click(object sender, EventArgs e)
        {

        }

        private void txtMedicalHis_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblMedicalHis_Click(object sender, EventArgs e)
        {

        }

        private void cmbBloodGroup_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblBloodGroup_Click(object sender, EventArgs e)
        {

        }

        private void lblOrganType_Click(object sender, EventArgs e)
        {

        }

        private void cmbGender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblGender_Click(object sender, EventArgs e)
        {

        }

        private void lblSearch_Click(object sender, EventArgs e)
        {

        }

        private void dgvDonors_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbCrossmatch_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblAddress_Click(object sender, EventArgs e)
        {

        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblContact_Click(object sender, EventArgs e)
        {

        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblLastName_Click(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }

        private void txtDonorID_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblDonorID_Click(object sender, EventArgs e)
        {

        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblFirstName_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxProfilePicture_Click(object sender, EventArgs e)
        {

        }

        private void lblProfilePicture_Click(object sender, EventArgs e)
        {

        }

        private void panelTop_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
