﻿using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

public class EmailHelper
{
    public async Task SendEmailAsync(string recipientEmail, string subject, string body)
    {
        // Configure the SMTP client with Gmail's settings
        SmtpClient client = new SmtpClient("smtp.gmail.com", 587)
        {
            Credentials = new NetworkCredential("chopadeaditya12@gmail.com", "yiwz chki zwbi salp"),
            EnableSsl = true
        };

        MailMessage mail = new MailMessage();
        mail.From = new MailAddress("chopadeaditya12@gmail.com");  // Your Gmail address
        mail.To.Add(recipientEmail);                           // Recipient's email
        mail.Subject = subject;
        mail.Body = body;
        mail.IsBodyHtml = false;  // Change to true if you want to send HTML email

        await client.SendMailAsync(mail);
    }
}
