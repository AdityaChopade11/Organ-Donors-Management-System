﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace OrganDonorsManagementSystem.Helpers
{
    public class Fast2SmsQuickSender
    {
        private static readonly HttpClient client = new HttpClient();

        /// <summary>
        /// Sends an SMS using Fast2SMS Quick API.
        /// </summary>
        /// <param name="phoneNumber">The recipient's phone number (must be 10 digits, no country code).</param>
        /// <param name="message">The SMS message to send.</param>
        /// <returns>The API response as a string.</returns>
        public async Task<string> SendQuickSmsAsync(string phoneNumber, string message)
        {
            // Validate phone number format (must be 10 digits)
            if (string.IsNullOrWhiteSpace(phoneNumber) || phoneNumber.Length != 10 || !phoneNumber.All(char.IsDigit))
            {
                return "Error: Invalid phone number format.";
            }

            string apiKey = "4HIz38SjdWyGUik6eATNxEtZq5CgDm9KsFac2MX1QJwlovbhBPYVHgaRCSlnK4FEr6GAIu0fQvi8DNjO"; // Replace with actual API key
            string url = $"https://www.fast2sms.com/dev/bulkV2?authorization={apiKey}&route=q&message={Uri.EscapeDataString(message)}&numbers={phoneNumber}&flash=0";

            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("accept", "application/json");

            HttpResponseMessage response = await client.GetAsync(url);
            return await response.Content.ReadAsStringAsync();
        }
    }
}
