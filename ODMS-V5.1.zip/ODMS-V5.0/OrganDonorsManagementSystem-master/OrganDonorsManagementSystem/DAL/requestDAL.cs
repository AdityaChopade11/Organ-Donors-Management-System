﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Linq;
using OrganDonorsManagementSystem.BLL;
using System.Collections.Generic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace OrganDonorsManagementSystem.DAL
{
    public class requestDAL
    {
        static string myconnstrng = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;

        /// <summary>
        /// Advanced matching algorithm that uses ABO compatibility, HLA matching, 
        /// and a virtual crossmatch simulation.
        /// </summary>
        /// <param name="request">A requestBLL object containing organ_type, blood_type, and hla_markers.</param>
        /// <returns>A DataTable of donor records sorted by overall compatibility score (highest first).</returns>
        /// 

        public string GetRequesterEmail(int requestId)
        {
            string email = null;

            using (SqlConnection conn = new SqlConnection(myconnstrng))
            {
                try
                {
                    string query = "SELECT email FROM tbl_requests WHERE request_id = @request_id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@request_id", requestId);

                    conn.Open();
                    object result = cmd.ExecuteScalar();

                    if (result != null)
                        email = result.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
            }

            return email;
        }
        public DataTable AdvancedMatchDonor(requestBLL request)
        {
         

            DataTable donorData = new DataTable();
            try
            {
                using (SqlConnection conn = new SqlConnection(myconnstrng))
                {
                    // Retrieve donors with matching organ_type.
                    string sql = "SELECT * FROM tbl_donors WHERE organ_type = @organ_type AND donor_status = 'Available' AND organ_status = 'Valid' AND expiration_date > GETDATE()";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@organ_type", request.organ_type);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    conn.Open();
                    adapter.Fill(donorData);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving donors: " + ex.Message);
                return donorData;
            }

            MessageBox.Show("Donor rows found for organ_type '" + request.organ_type + "': " + donorData.Rows.Count);

            // Create a new DataTable to store donors with a computed CompatibilityScore.
            DataTable sortedDonors = donorData.Clone();
            sortedDonors.Columns.Add("CompatibilityScore", typeof(int));

            foreach (DataRow row in donorData.Rows)
            {
                int score = 0;
                // Handle donor_status: treat null or empty as "Available"
                string donorStatus = row["donor_status"]?.ToString().Trim();
                if (string.IsNullOrEmpty(donorStatus))
                    donorStatus = "Available";
                if (donorStatus != "Available")
                    continue;

                // ABO Compatibility
                string donorBlood = row["blood_group"]?.ToString().Trim().ToUpper() ?? "";
                string recipientBlood = request.blood_type?.Trim().ToUpper() ?? "";
                if (!IsBloodTypeCompatible(donorBlood, recipientBlood))
                    continue;
                else
                    score += 10;  // Base score for blood type match

                // HLA Matching
                string donorHLA = row["hla_markers"]?.ToString() ?? "";
                string recipientHLA = request.hla_markers ?? "";
                


                if (!string.IsNullOrEmpty(donorHLA) && !string.IsNullOrEmpty(recipientHLA))
                {
                   

                    int hlaScore = CalculateHLAMatchScore(donorHLA, recipientHLA);
                    score += hlaScore * 5;
                }

                // Urgency weighting
                string urgency = request.urgency?.Trim().ToUpper();
                switch (urgency)
                {
                    case "HIGH":
                        score += 20;
                        break;
                    case "MEDIUM":
                        score += 10;
                        break;
                    case "LOW":
                    default:
                        score += 0;
                        break;
                }

                // Virtual Crossmatch: treat null/empty as "NEGATIVE"
                string crossmatch = row["crossmatch_result"]?.ToString().Trim().ToUpper();
                if (string.IsNullOrEmpty(crossmatch) || crossmatch == "NEGATIVE")
                {
                    score += 5;
                }
                else
                {
                    continue;
                }

                // Add the donor row with the computed score.
                DataRow newRow = sortedDonors.NewRow();
                newRow.ItemArray = row.ItemArray;
                newRow["CompatibilityScore"] = score;
                sortedDonors.Rows.Add(newRow);
            }

            MessageBox.Show("Matches found: " + sortedDonors.Rows.Count);

            // Sort donors by CompatibilityScore (highest first).
            DataView dv = sortedDonors.DefaultView;
            dv.Sort = "CompatibilityScore DESC";
            return dv.ToTable();
        }

        private bool IsBloodTypeCompatible(string donorBlood, string recipientBlood)
        {
            // Convert both to uppercase for consistency
            donorBlood = donorBlood.ToUpper();
            recipientBlood = recipientBlood.ToUpper();

            // More fluid ABO+Rh compatibility for organ transplants
            var compatibilityMap = new Dictionary<string, List<string>>
    {
        { "O-",  new List<string> { "O-", "A-", "B-", "AB-" } }, // Universal donor for Rh- 
        { "O+",  new List<string> { "O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+" } }, // Universal donor for Rh+
        { "A-",  new List<string> { "A-", "AB-" } },
        { "A+",  new List<string> { "A-", "A+", "AB-", "AB+" } },
        { "B-",  new List<string> { "B-", "AB-" } },
        { "B+",  new List<string> { "B-", "B+", "AB-", "AB+" } },
        { "AB-", new List<string> { "AB-" } },
        { "AB+", new List<string> { "AB-", "AB+" } } // AB+ is universal recipient
    };

            // If recipient's blood type isn't recognized, automatically fail
            if (!compatibilityMap.ContainsKey(recipientBlood))
                return false;

            // Check if the donor's blood type is in the list of compatible types
            return compatibilityMap[recipientBlood].Contains(donorBlood);
        }

        public int CalculateHLAMatchScore(string donorHLA, string recipientHLA)


        {
            
            var donorMarkers = donorHLA.Split(new char[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                                       .Select(x => x.Trim().ToUpper());
            var recipientMarkers = recipientHLA.Split(new char[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                                               .Select(x => x.Trim().ToUpper());
            return donorMarkers.Intersect(recipientMarkers).Count();
        }

        // Legacy stub (if other parts of the code call MatchDonor)
        public DataTable MatchDonor(string organType, string bloodType)
        {
            requestBLL req = new requestBLL
            {
                organ_type = organType,
                blood_type = bloodType,
                hla_markers = ""  // Leave empty if not available
            };
            return AdvancedMatchDonor(req);
        }

        // The remaining methods remain unchanged...
        public bool Insert(requestBLL r)
        {
            bool isSuccess = false;
            using (SqlConnection conn = new SqlConnection(myconnstrng))
            {
                try
                {
                    string sql = "INSERT INTO tbl_requests(" +
                                 "patient_name, organ_type, blood_type, Medical_History, contact, status, " +
                                 "hla_markers, requester_email, urgency, gender, address, profile_picture, requested_date, added_by)" +
                                 " VALUES(" +
                                 "@patient_name, @organ_type, @blood_type, @Medical_History, @contact, @status, " +
                                 "@hla_markers, @requester_email, @urgency, @gender, @address, @profile_picture, @requested_date, @added_by)";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@patient_name", r.patient_name);
                        cmd.Parameters.AddWithValue("@organ_type", r.organ_type);
                        cmd.Parameters.AddWithValue("@blood_type", r.blood_type);
                        cmd.Parameters.AddWithValue("@Medical_History", r.Medical_History ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@contact", r.contact);
                        cmd.Parameters.AddWithValue("@status", r.status);
                        cmd.Parameters.AddWithValue("@hla_markers", r.hla_markers ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@requester_email", r.requester_email);
                        cmd.Parameters.AddWithValue("@urgency", r.urgency);
                        cmd.Parameters.AddWithValue("@gender", r.gender);
                        cmd.Parameters.AddWithValue("@address", r.address);

                        if (r.profile_picture != null)
                            cmd.Parameters.AddWithValue("@profile_picture", r.profile_picture);
                        else
                            cmd.Parameters.Add("@profile_picture", System.Data.SqlDbType.VarBinary).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("@requested_date", r.requested_date);
                        cmd.Parameters.AddWithValue("@added_by", r.added_by);

                        conn.Open();
                        int rows = cmd.ExecuteNonQuery();
                        isSuccess = rows > 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            return isSuccess;
        }

        public DataTable Select()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(myconnstrng))
            {
                string sql = "SELECT * FROM tbl_requests";
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    conn.Open();
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        
        public DataTable GetRequestsByStatus(string status)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(myconnstrng))
            {
                string sql = "SELECT * FROM tbl_requests WHERE status = @status";
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@status", status);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    conn.Open();
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetIncompatibleDonors()
        {
            DataTable dt = new DataTable();

            try
            {
                string sql = "SELECT * FROM tbl_donors WHERE crossmatch_result = 'POSITIVE'";
                using (SqlConnection conn = new SqlConnection(myconnstrng))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    conn.Open();
                    adapter.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return dt;
        }

        public DataTable GetAllRequests()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(myconnstrng))
            {
                string sql = "SELECT * FROM tbl_requests";
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    conn.Open();
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        
    }
}
