﻿using OrganDonorsManagementSystem.BLL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrganDonorsManagementSystem.DAL
{
    class donorDAL
    {
        //Create a Connection String to Connect Database
        static string myconnstrng = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;
        #region SELECT to display data in DataGridView from database
        public DataTable Select()
        {
            // Create object to DataTAble to hold the data from database and return it
            DataTable dt = new DataTable();

            //Create object of SQL Connection to Connect DAtabase
            SqlConnection conn = new SqlConnection(myconnstrng);

            try
            {
                //Write SQL Query to SElect the DAta from DAtabase
                string sql = "SELECT * FROM tbl_donors";

                //Create the SQlCommand to Execute the Query
                SqlCommand cmd = new SqlCommand(sql, conn);

                //Create SQl DAta Adapter to Hold the Data Temporarily
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                //open Database Connection
                conn.Open();

                //Pass the Data from adapter to DataTable
                adapter.Fill(dt);
            }
            catch(Exception ex)
            {
                //Display Message if there's any Exceptional Errors
                MessageBox.Show(ex.Message);
            }
            finally
            {
                //Close Database Connection
                conn.Close();
            }

            return dt;
        }
        #endregion
        #region INSERT data to database
        public bool Insert(donorBLL d)
        {
            bool isSuccess = false;
            using (SqlConnection conn = new SqlConnection(myconnstrng))
            {
                try
                {
                    string sql = @"INSERT INTO tbl_donors 
                           (first_name, last_name, email, contact, gender, address, organ_type, 
                            added_date, added_by, blood_group, Medical_History, hla_markers, 
                            crossmatch_result, donor_status, profile_picture, expiration_date, organ_status)
                           VALUES
                           (@first_name, @last_name, @email, @contact, @gender, @address, @organ_type,
                            @added_date, @added_by, @blood_group, @Medical_History, @hla_markers,
                            @crossmatch_result, @donor_status, @profile_picture, @expiration_date, @organ_status)";

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    // Existing parameters
                    cmd.Parameters.AddWithValue("@first_name", d.first_name);
                    cmd.Parameters.AddWithValue("@last_name", d.last_name);
                    cmd.Parameters.AddWithValue("@email", d.email);
                    cmd.Parameters.AddWithValue("@contact", d.contact);
                    cmd.Parameters.AddWithValue("@gender", d.gender);
                    cmd.Parameters.AddWithValue("@address", d.address);
                    cmd.Parameters.AddWithValue("@organ_type", d.organ_type);
                    cmd.Parameters.AddWithValue("@added_date", d.added_date);
                    cmd.Parameters.AddWithValue("@added_by", d.added_by);
                    cmd.Parameters.AddWithValue("@blood_group", d.blood_group);
                    cmd.Parameters.AddWithValue("@Medical_History", d.Medical_History ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@hla_markers", d.hla_markers ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@crossmatch_result", d.crossmatch_result ?? "NEGATIVE");
                    cmd.Parameters.AddWithValue("@donor_status", d.donor_status ?? "Available");
                    cmd.Parameters.AddWithValue("@expiration_date", d.expiration_date);
                    cmd.Parameters.AddWithValue("@organ_status", d.organ_status);
                    // NEW: profile_picture
                    if (d.profile_picture != null)
                        cmd.Parameters.AddWithValue("@profile_picture", d.profile_picture);
                    else
                        cmd.Parameters.Add("@profile_picture", System.Data.SqlDbType.VarBinary).Value = DBNull.Value;

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    isSuccess = rows > 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            return isSuccess;
        }
        #endregion
        #region UPDATE donors in DAtabase
        public bool Update(donorBLL d)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstrng);

            try
            {
                string sql = @"UPDATE tbl_donors 
               SET first_name=@first_name, last_name=@last_name, email=@email,
                   gender=@gender, organ_type=@organ_type, blood_group=@blood_group,
                   Medical_History=@Medical_History, hla_markers=@hla_markers,
                   crossmatch_result=@crossmatch_result, contact=@contact, address=@address,
                   profile_picture=@profile_picture
               WHERE donor_id=@donor_id";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@first_name", d.first_name);
                cmd.Parameters.AddWithValue("@last_name", d.last_name);
                cmd.Parameters.AddWithValue("@email", d.email);
                cmd.Parameters.AddWithValue("@gender", d.gender);
                cmd.Parameters.AddWithValue("@organ_type", d.organ_type);
                cmd.Parameters.AddWithValue("@blood_group", d.blood_group);
                cmd.Parameters.AddWithValue("@medical_history", d.Medical_History);
                cmd.Parameters.AddWithValue("@hla_markers", d.hla_markers);
                cmd.Parameters.AddWithValue("@crossmatch_result", d.crossmatch_result);
                cmd.Parameters.AddWithValue("@contact", d.contact);
                cmd.Parameters.AddWithValue("@address", d.address);
                cmd.Parameters.AddWithValue("@donor_id", d.donor_id);

                if (d.profile_picture != null)
                {
                    cmd.Parameters.AddWithValue("@profile_picture", d.profile_picture);
                }
                else
                {
                    cmd.Parameters.Add("@profile_picture", SqlDbType.VarBinary).Value = DBNull.Value;
                }

                conn.Open();
                int rows = cmd.ExecuteNonQuery();

                isSuccess = rows > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        } // End of Update method

        #endregion
        #region DELETE donros from Database
        public bool Delete(donorBLL d)
        {
            //Create a Boolean variable and set its default value to false
            bool isSuccess = false;
            //Create SqlConnection To Connect DAtabase
            SqlConnection conn = new SqlConnection(myconnstrng);

            try
            {
                //Write the Query to Delete Donors from Database
                string sql = "DELETE FROM tbl_donors WHERE donor_id=@donor_id";

                //Create SQL Command
                SqlCommand cmd = new SqlCommand(sql, conn);

                //Pass the Value to Sql Query using Parameters
                cmd.Parameters.AddWithValue("@donor_id", d.donor_id);

                //Open Database Connection
                conn.Open();

                //Create an Integer VAriable to Check whether the query executed Successfully or Not
                int rows = cmd.ExecuteNonQuery();

                //If the Query executed succesfully then the value of rows will be greater than 0 else it will be 0
                if(rows>0)
                {
                    //Query Executed Successfully
                    isSuccess = true;
                }
                else
                {
                    //FAiled to Exeute Query
                    isSuccess = false;
                }
            }
            catch(Exception ex)
            {
                //Display Error Message if there's any Exceptional Errors
                MessageBox.Show(ex.Message);
            }
            finally
            {
                //CLose Database Connection
                conn.Close();
            }

            return isSuccess;
        }
        #endregion

        #region Count Donors for Specific organ_type
        public string countDonors(string organ_type)
        {
            //Create SQL Connection for Database Connection
            SqlConnection conn = new SqlConnection(myconnstrng);

            //Create astring variable for donor count and set its default value to 0
            string donors = "0";

            try
            {
                //SQL Query to Count donors for Specific Blood Group
                string sql = "SELECT * FROM tbl_donors WHERE organ_type = '" + organ_type + "'";

                //Sql Command to Execute Query
                SqlCommand cmd = new SqlCommand(sql, conn);

                //Sql Data Adapter to Get the data from DAtabase
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                //Databale to Hold the DAta Temporarily
                DataTable dt = new DataTable();

                //Pass tehe value from SqlDataAdapter to DataTable
                adapter.Fill(dt);

                //Get the Total Number of Donors Based on Blood Group
                donors = dt.Rows.Count.ToString();
            }
            catch(Exception ex)
            {
                //Display error message if there's any
                MessageBox.Show(ex.Message);
            }
            finally
            {
                //Close Database Connection
                conn.Close();
            }

            return donors;
        }
        #endregion

        #region Method to Search Donors
        public DataTable Search(string keywords)
        {
            //1. SQL Connection to Connect DAtabase
            SqlConnection conn = new SqlConnection(myconnstrng);

            //2. Create DataTable to hold the data Temporarily
            DataTable dt = new DataTable();

            try
            {
                //Write the Code to Search Donors based on Keywords Typed on TextBox
                //Write SQL Query to SEarch Donors
                string sql = "SELECT * FROM tbl_donors WHERE donor_id LIKE '%"+ keywords +"%' OR first_name LIKE '%"+keywords+"%' OR last_name LIKE '"+keywords+"' OR email LIKE '%"+ keywords + "%' OR organ_type LIKE '" + keywords+"'";

                //Create SQL Command to Execute the Query
                SqlCommand cmd = new SqlCommand(sql, conn);

                //SQlDataAdapter to Save Data from Database
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                //Open Database Connection
                conn.Open();

                //Transfer the Data from SQL Data Adapter to DataTable
                adapter.Fill(dt);
            }
            catch(Exception ex)
            {
                //Display Error Message if there's any Exceptional Errors
                MessageBox.Show(ex.Message);
            }
            finally
            {
                //Close the DAtabase Connection
                conn.Close();
            }

            return dt;
        }

        public bool UpdateDonorStatus(int donor_id, string newStatus)
        {
            {
                string connectionString = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    try
                    {
                        // Prepare command before opening connection
                        string sql = "UPDATE tbl_donors SET donor_status = @newStatus WHERE donor_id = @donorId";
                        SqlCommand cmd = new SqlCommand(sql, conn);
                        cmd.Parameters.AddWithValue("@newStatus", newStatus);
                        cmd.Parameters.AddWithValue("@donorId", donor_id);

                        conn.Open();
                        return cmd.ExecuteNonQuery() > 0;
                    }
                    catch (Exception ex)
                    {
                        // Provide context with error message
                        MessageBox.Show("Failed to update donor status: " + ex.Message);
                        return false;
                    }
                    // No need for finally as using handles connection closing
                }

            }
        }
        public DataTable GetDonorById(int donorId)
        {
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(myconnstrng))
            {
                try
                {
                    string sql = "SELECT * FROM tbl_donors WHERE donor_id = @donor_id";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@donor_id", donorId);
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        conn.Open();
                        adapter.Fill(dt);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
            }

            return dt;
        }


        public void UpdateExpiredOrgans()
        {
            using (SqlConnection conn = new SqlConnection(myconnstrng))
            {
                try
                {
                    conn.Open();
                    string sql = "UPDATE tbl_donors SET organ_status = 'Expired' WHERE expiration_date <= GETDATE() AND organ_status != 'Expired'";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating expired organs: " + ex.Message);
                }
            }
        }


        #endregion
    }
}
