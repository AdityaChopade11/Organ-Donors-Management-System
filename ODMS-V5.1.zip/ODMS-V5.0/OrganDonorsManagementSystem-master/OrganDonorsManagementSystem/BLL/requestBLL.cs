﻿using System;

namespace OrganDonorsManagementSystem.BLL
{
     public class requestBLL
    {
        public int request_id { get; set; }
        public string patient_name { get; set; }
        public string organ_type { get; set; }
        public string blood_type { get; set; }
        
        public string Medical_History { get; set; }
        public string contact { get; set; }
        public string requester_email { get; set; }

        public string status { get; set; }
        public DateTime requested_date { get; set; }

        public string urgency { get; set; }
         public int added_by {  get; set; }
        public string gender { get; set; }
        public string address { get; set; }
        public DateTime added_date { get; set; }
        
        public byte[] profile_picture { get; set; }
        public string hla_markers { get; set; }       // Recipient's HLA markers, if available

    }
}
