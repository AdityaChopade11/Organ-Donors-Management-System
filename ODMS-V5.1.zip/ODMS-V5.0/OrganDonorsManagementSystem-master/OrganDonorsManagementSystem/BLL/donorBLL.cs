﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrganDonorsManagementSystem.BLL
{
    class donorBLL
    {
        public int donor_id { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string email { get; set; }
        public string contact { get; set; }
        public string gender { get; set; }
        public string address { get; set; }
        public string organ_type { get; set; }

        public string Medical_History { get; set; }
        public string blood_group { get; set; }
        public DateTime added_date { get; set; }
        public byte[] profile_picture { get; set; }

        public int added_by { get; set; }

        public DateTime expiration_date { get; set; }
        public string organ_status { get; set; }

        public string hla_markers { get; set; }       // Example: "A1,A2,B7,B8,DR15,DR17"
        public string crossmatch_result { get; set; }
        public string donor_status { get; set; } // Example: "Negative" or "Positive"

    }
}
